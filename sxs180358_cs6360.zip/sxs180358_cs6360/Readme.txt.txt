Contact Address Book

Dependencies:
1. MySQL Server: The below details were used and mentioned for MySQL connection in java.
	a. Port: 3306
	b. Username: root
	c. Password: admin
2. Eclipse IDE for Enterprise Java Developers for editing Java and jsp code
3. Apache Tomcat : localhost:8080

Deployment of project:
1. Open MySQL WorkBench and create a new database called contacts. Type "USE contacts;".
Then create tables using the database script attached in the folder.
2. Import contact.csv, address.csv, phone.csv, Date.csv provided in the folder to MySQL Database using import tab.
3. Open the Eclipse IDE and  click on Dynamic web project.
4. Set the runtime server as Apache Tomcat 9.0
5. Import the project into IDE from zip file.
6. Inside IDE go to properties of the project and click on Build data path and "Add variables". The jar files are to be added.
7. Click on Deployment assembly, click add and on the java build path entries. Add the java build path entries.
8. Right click on index.jsp inside webContent and click run on server to execute the project.  