package com.sharanya.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.sharanya.bean.Contact;
public class UsercontactDao {
	public static Connection getConnection(){
		Connection con=null;
	    System.out.println("Connecting............");
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/contacts","root","admin");
		}catch(Exception e){System.out.println(e);}
		return con;
	}

public static int saveContact(Contact u){
	int status=0;	 
	try{
		Connection con=getConnection();
		System.out.println("Connected and saving contact............" + u.getFirstname() +"-"+ u.getMiddlename() +"-"+u.getLastname() );
		PreparedStatement ps=con.prepareStatement("insert into contact (First_name,Middle_name, Last_name) values(?,?,?)",Statement.RETURN_GENERATED_KEYS);
		
		ps.setString(1,u.getFirstname());
		ps.setString(2,u.getMiddlename());
		ps.setString(3,u.getLastname());
		
		status=ps.executeUpdate();

		try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
            if (generatedKeys.next()) {
                u.setContactid(generatedKeys.getInt(1));
            status=generatedKeys.getInt(1);
            System.out.println("Inserted Contact with ID: "+ status);
            }
            else {
                throw new SQLException("Creating user failed, no ID obtained.");
            }
		}
		catch(Exception e) {}
	
	}catch(Exception e){System.out.println(e);}
	return status;
}

public static int updateContact(Contact u){
	int status=0;	 
	try{
		Connection con=getConnection();
		System.out.println("Connected and updating contact............" + u.getFirstname() +"-"+ u.getMiddlename() +"-"+u.getLastname() );
		String rem_mid = (String) u.getMiddlename();
		String rem_fir = (String) u.getFirstname();
		String rem_las = (String) u.getLastname();
		if(rem_mid.equals("null")) {
			u.setMiddlename("");
		}
		if(rem_fir.equals("null")) {
			u.setFirstname("");
		}
		if(rem_las.equals("null")) {
			u.setLastname("");
		}
		PreparedStatement ps=con.prepareStatement("update contact set First_name=?,Middle_name=?,Last_name=? where contact_id=?");
				
		ps.setString(1,u.getFirstname());
		ps.setString(2,u.getMiddlename());
		ps.setString(3,u.getLastname());
		ps.setInt(4, u.getContactid());	
		status=ps.executeUpdate();		
	
	}catch(Exception e){System.out.println(e);}
	return status;
}

// phone
public static int savePhone(Contact u){
	int status=0;	
 
	try{
		Connection con=getConnection();
		System.out.println("Connected and saving phone............");
		PreparedStatement ps=con.prepareStatement("insert into phone (contact_id,phone_type,area_code,mobile_number) values(?,?,?,?)",Statement.RETURN_GENERATED_KEYS);
		System.out.println(u.getContactid());
		ps.setInt(1,u.getContactid());
		ps.setString(2,u.getPhonetype());
		ps.setString(3,u.getAreacode());
		ps.setString(4,u.getNumber());
		status=ps.executeUpdate();
		System.out.println("InsertedPhone");
			try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
	            if (generatedKeys.next()) {
	                u.setPhoneid(generatedKeys.getInt(1));
	            status=generatedKeys.getInt(1);
	            System.out.println("Inserted Phone with ID: "+ status);
	            }
	            else {
	                throw new SQLException("Creating user failed, no phone ID obtained.");
	            }
			}
			catch(Exception e) {}
	}catch(Exception e){System.out.println(e);}
	return status;
}
public static int updatePhone(Contact u){
	int status=0;	
 
	try{
		Connection con=getConnection();
		System.out.println("Connected and updating phone............" + u.getPhoneid());
		PreparedStatement ps=con.prepareStatement("Update phone Set phone_type=?,area_code=?,mobile_number=? where contact_id= ? ");
		ps.setString(1,u.getPhonetype());
		ps.setString(2,u.getAreacode());
		ps.setString(3,u.getNumber());
		ps.setInt(4,u.getContactid());
		
		status=ps.executeUpdate();
	}catch(Exception e){System.out.println(e);}
	return status;
}

//address
public static int saveAddress(Contact u){
	int status=0;	
 
	try{
		Connection con=getConnection();
		   System.out.println("Connected and saving............");
		PreparedStatement ps=con.prepareStatement("insert into address (contact_id,address_type,address,city,state,zip) values(?,?,?,?,?,?)");
		   System.out.println("Inserted...."+u.getAddresstype() + u.getContactid());
		   
		ps.setInt(1,u.getContactid());
		ps.setString(2,u.getAddresstype());
		ps.setString(3,u.getAddress());
		ps.setString(4,u.getCity());
		ps.setString(5,u.getState());
		ps.setString(6,u.getZip());
		
		status=ps.executeUpdate();
	}catch(Exception e){System.out.println(e);}
	return status;
}

public static int updateAddress(Contact u){
	int status=0;	
 
	try{
		Connection con=getConnection();
		   System.out.println("Connected and saving............");
		PreparedStatement ps=con.prepareStatement("Update address Set contact_id=?,address_type=?,address=?,city=?,state=?,zip=? where contact_id=?");
		   System.out.println("updating Address....");
		   
		ps.setInt(1,u.getContactid());
		ps.setString(2,u.getAddresstype());
		ps.setString(3,u.getAddress());
		ps.setString(4,u.getCity());
		ps.setString(5,u.getState());
		ps.setString(6,u.getZip());
		ps.setInt(7,u.getContactid());
		
		status=ps.executeUpdate();
	}catch(Exception e){System.out.println(e);}
	return status;
}
//Date
public static int saveDate(Contact u){
	int status=0;	
 
	try{
		Connection con=getConnection();
		   System.out.println("Connected and saving............");
		PreparedStatement ps=con.prepareStatement("insert into Date (contact_id,date_type,Date_day) values(?,?,?)",Statement.RETURN_GENERATED_KEYS);
		   System.out.println("Inserted.");
	    ps.setInt(1,u.getContactid());
		ps.setString(2,u.getDatetype());
		ps.setString(3,u.getDateday());
		status=ps.executeUpdate();
		try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
		if (generatedKeys.next()) {
	            u.setDateid(generatedKeys.getInt(1));
	            status=generatedKeys.getInt(1);
	            System.out.println("Inserted Date with ID: "+ status);
	    }
		else {
	            throw new SQLException("Creating user failed, no Date ID obtained.");
	        }
		}
		catch(Exception e) {}
	}catch(Exception e){System.out.println(e);}
	return status;
}
public static int updateDate(Contact u){
	int status=0;	
 
	try{
		Connection con=getConnection();
		   System.out.println("Connected and saving............");
		PreparedStatement ps=con.prepareStatement("Update Date Set date_type=?,Date_day=? where contact_id=?");
		   System.out.println("Updating Date....");	
		ps.setString(1,u.getDatetype());
		ps.setString(2,u.getDateday());
	    ps.setInt(3,u.getContactid());
	    
		status=ps.executeUpdate();
	}catch(Exception e){System.out.println(e);}
	return status;
}
//Delete
public static int delete(int Contactid){
	int status=0;
	try{
		Connection con=getConnection();
		PreparedStatement ps=con.prepareStatement("delete from phone where contact_id=?");
		ps.setInt(1,Contactid);
		status=ps.executeUpdate();
		  System.out.println("Deleted Phone for contact id."+Contactid);
		PreparedStatement ps1=con.prepareStatement("delete from address where contact_id=?");
		ps1.setInt(1,Contactid);
		status=ps1.executeUpdate();
		  System.out.println("Deleted address for contact id."+Contactid);
		PreparedStatement ps2=con.prepareStatement("delete from date where contact_id=?");
		ps2.setInt(1,Contactid);
		status=ps2.executeUpdate();
		  System.out.println("Deleted date for contact id."+Contactid);
		PreparedStatement ps3=con.prepareStatement("delete from contact where contact_id=?");
		ps3.setInt(1,Contactid);
		status=ps3.executeUpdate();
		  System.out.println("Deleted contact for contact id."+Contactid);
	}catch(Exception e){System.out.println(e);}

	return status;
}
//Get all records done in jsp including connection to database and sql querry
//Search
public static List<Contact> getSearchRecords(Contact ud){
	List<Contact> list=new ArrayList<Contact>();
	try{
		String SearchString = ud.getSearchtext();
		System.out.println("Search for.."+ud.getSearchtext());
		Connection con=getConnection();
		PreparedStatement ps=con.prepareStatement("select c.*,p.* ,a.*,d.* from  contact c left join phone p    on c.contact_id = p.contact_id left join address a    on c.contact_id = a.contact_id left join date d    on c.contact_id = d.contact_id where (c.First_name LIKE '"+SearchString+"' or c.Middle_name LIKE '"+SearchString+"' or c.Last_name LIKE '"+SearchString+"' or a.address_type LIKE '"+SearchString+"' or a.address LIKE '"+SearchString+"' or a.city LIKE '"+SearchString+"' or a.state LIKE '"+SearchString+"' or a.zip LIKE '"+SearchString+"' or p.phone_type LIKE '"+SearchString+"' or p.area_code LIKE '"+SearchString+"' or p.mobile_number LIKE '"+SearchString+"' or d.date_type LIKE '"+SearchString+"' or d.Date_day LIKE '"+SearchString+"' or c.contact_id LIKE '"+SearchString+"')");
		ResultSet rs=ps.executeQuery();
		while(rs.next()){		
			Contact u=new Contact();			
			u.setContactid(rs.getInt("Contact_Id"));
			u.setFirstname(rs.getString("First_name"));
			u.setMiddlename(rs.getString("Middle_name"));
			u.setLastname(rs.getString("Last_name"));
			u.setPhoneid(rs.getInt("phone_id"));
			u.setNumber(rs.getString("mobile_number"));
			u.setPhonetype(rs.getString("Phone_type"));	
			u.setAreacode(rs.getString("area_code"));
			u.setAddressid(rs.getInt("address_id"));
			u.setAddresstype(rs.getString("address_type"));
			u.setAddress(rs.getString("address"));
			u.setCity(rs.getString("city"));
			u.setState(rs.getString("state"));
			u.setZip(rs.getString("zip"));
			u.setDateid(rs.getInt("date_id"));
			u.setDatetype(rs.getString("date_type"));
			u.setDateday(rs.getString("date_day"));	
			
			list.add(u);
			
		}
		System.out.print(list);
	}catch(Exception e){System.out.println(e);}
	return list;
}
public static Contact getRecordByContactId(int ContactId){
	Contact  u=null;
	try{
		if(ContactId !=0)
		{
			
		
		Connection con=getConnection();
		PreparedStatement ps=con.prepareStatement("select c.*,p.* ,a.*,d.* from  contact c left join phone p    on c.contact_id = p.contact_id left join address a    on c.contact_id = a.contact_id left join date d    on c.contact_id = d.contact_id	 where c.contact_id=?");
		ps.setInt(1,ContactId);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			u=new Contact();
			
			u.setContactid(rs.getInt("Contact_Id"));
			u.setFirstname(rs.getString("First_name"));
			u.setMiddlename(rs.getString("Middle_name"));
			u.setLastname(rs.getString("Last_name"));
			u.setPhoneid(rs.getInt("phone_id"));
			u.setNumber(rs.getString("mobile_number"));
			u.setPhonetype(rs.getString("Phone_type"));	
			u.setAreacode(rs.getString("area_code"));
			u.setAddressid(rs.getInt("address_id"));
			u.setAddresstype(rs.getString("address_type"));
			u.setAddress(rs.getString("address"));
			u.setCity(rs.getString("city"));
			u.setState(rs.getString("state"));
			u.setZip(rs.getString("zip"));
			u.setDateid(rs.getInt("date_id"));
			u.setDatetype(rs.getString("date_type"));
			u.setDateday(rs.getString("date_day"));
		}
		}
	}catch(Exception e){System.out.println(e);}
	return u;
}


}
